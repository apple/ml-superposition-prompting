import copy
import csv
import functools
import gc
import json
import math
import os

# import matplotlib.pyplot as plt
import pathlib
import pprint
import threading
import time
from collections import defaultdict
from contextlib import contextmanager
from dataclasses import dataclass
from functools import partial
from time import perf_counter as press_button
from typing import *

import humanize
import lorem
import more_itertools
import numpy as np
import pandas as pd
import torch
import transformers
from datasets import load_dataset
from kink import di, inject
from rank_bm25 import BM25Okapi
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from torch import nn
from transformers import AutoConfig, AutoModel, AutoModelForCausalLM, AutoTokenizer
from transformers.generation import GenerationConfig
from transformers.models.bloom import BloomPreTrainedModel
from transformers.models.bloom.modeling_bloom import BloomForCausalLM
from transformers.models.mpt.modeling_mpt import MptForCausalLM

Cache = "Cache"

# Dataset properties
N_TOKENS_PREAMBLE = 39
N_TOKENS_CTX = 137
N_TOKENS_QUERY = 11
N_TOKENS_TASK = 13
N_TOKENS_GEN = 5

N_CTXS = 20


class ModelCachableNoKwargs(nn.Module):
    def __init__(self, model):
        super().__init__()
        self.model = model

        # Stupid hack needed since fvcore doesn't support kwargs.
        self.past_key_values = None

    def forward(self, inputs):
        return self.model(inputs, past_key_values=self.past_key_values)


def cache_len(model_type, cache):
    assert cache is not None
    if model_type == BloomForCausalLM:
        return cache[0][0].shape[-1]
    elif model_type == MptForCausalLM:
        return cache[0][0].shape[-2]
    else:
        assert False


def _slice_cache_sequence(model_type, cache, slc):
    if model_type == BloomForCausalLM:
        k_dim_idx = -1
        v_dim_idx = -2
    elif model_type == MptForCausalLM:
        k_dim_idx = -2
        v_dim_idx = -2
    else:
        assert False

    #  - key: [batch_size * self.num_heads, head_dim, kv_length]
    #  - value: [batch_size * self.num_heads, kv_length, head_dim]
    # assert all(all(len(layer_kv) == 2 for layer_kv in kv_block) for kv_block in kv_blocks)
    # assert all(len(kv_block) == len(kv_blocks[0]) for kv_block in kv_blocks)
    if model_type == BloomForCausalLM:
        res_k = tuple(cache[lidx][0][..., slc] for lidx in range(len(cache)))
    elif model_type == MptForCausalLM:
        res_k = tuple(cache[lidx][0][..., slc, :] for lidx in range(len(cache)))
    else:
        assert False
    res_v = tuple(cache[lidx][1][..., slc, :] for lidx in range(len(cache)))
    res = tuple(zip(res_k, res_v))
    return res


def _concatenate_kv_caches(
    model_type, kv_blocks, dim: Literal["batch", "sequence"] = "sequence"
):
    assert len(kv_blocks) > 1
    assert dim in ["batch", "sequence"]
    if model_type == BloomForCausalLM:
        k_dim_idx = 0 if dim == "batch" else -1
        v_dim_idx = 0 if dim == "batch" else -2
    elif model_type == MptForCausalLM:
        k_dim_idx = 0 if dim == "batch" else -2
        v_dim_idx = 0 if dim == "batch" else -2
    else:
        assert False

    #  - key: [batch_size * self.num_heads, head_dim, kv_length]
    #  - value: [batch_size * self.num_heads, kv_length, head_dim]
    assert all(
        all(len(layer_kv) == 2 for layer_kv in kv_block) for kv_block in kv_blocks
    )
    assert all(len(kv_block) == len(kv_blocks[0]) for kv_block in kv_blocks)
    res_k = tuple(
        torch.cat(
            [kv_blocks[block_idx][lidx][0] for block_idx in range(len(kv_blocks))],
            dim=k_dim_idx,
        )
        for lidx in range(len(kv_blocks[0]))
    )
    res_v = tuple(
        torch.cat(
            [kv_blocks[block_idx][lidx][1] for block_idx in range(len(kv_blocks))],
            dim=v_dim_idx,
        )
        for lidx in range(len(kv_blocks[0]))
    )
    res = tuple(zip(res_k, res_v))
    return res


def _dist_tensor(tensor: torch.Tensor, n_devices):
    return [p.to(f"cuda:{i}") for i, p in enumerate([tensor] * n_devices)]


def _dist_tensor_list(tensors: List[torch.Tensor], n_devices):
    print([f"cuda:{i}" for i in range(n_devices)])
    # assert len(tensors) % n_devices == 0
    tensor_shards = more_itertools.chunked_even(
        tensors, int(math.ceil(len(tensors) / n_devices))
    )
    return [[c.to(f"cuda:{i}") for c in chunk] for i, chunk in enumerate(tensor_shards)]


def _dist_cache(cache: Cache, n_devices):
    def _to(x: torch.Tensor, i: int):
        return x.to(f"cuda:{i}")

    return [
        apply_to_cache(copy.deepcopy(cache), partial(_to, i=i))
        for i in range(n_devices)
    ]


def _dist_cache_list(cache_list: List[Cache], n_devices):
    def _to(x: torch.Tensor, i: int):
        return x.to(f"cuda:{i}")

    return [
        [
            # apply_to_cache(copy.deepcopy(cache), partial(_to, i=i))
            apply_to_cache(cache, partial(_to, i=i))
            for cache in cache_list
        ]
        for i, cache_list in enumerate(
            more_itertools.chunked_even(
                cache_list, int(math.ceil(len(cache_list) / n_devices))
            )
        )
    ]


def _broadcast_cache_batch(model_type, cache, size: int):
    # broadcaster_tensor = torch.zeros([size, 1, 1, 1])
    if model_type == BloomForCausalLM:
        return BloomPreTrainedModel._convert_to_bloom_cache(
            apply_to_cache(cache, lambda x: x.expand(size, -1, -1, -1).contiguous())
        )
    elif model_type == MptForCausalLM:
        return apply_to_cache(cache, lambda x: x.expand(size, -1, -1, -1).contiguous())
    else:
        assert False


def _select_from_batch(model_type, cache, batch_size, idxs: Sequence[int] = [0]):
    if model_type == BloomForCausalLM:
        branch_cache = BloomPreTrainedModel._convert_to_standard_cache(
            cache, batch_size=batch_size
        )
        return [apply_to_cache(branch_cache, lambda x: x[idx, :, :, :]) for idx in idxs]
    elif model_type == MptForCausalLM:
        return [apply_to_cache(cache, lambda x: x[[idx], :, :, :]) for idx in idxs]
    else:
        assert False


def apply_to_cache(kv_cache, callable):
    return tuple(
        tuple(callable(k_or_v) for k_or_v in layer_cache) for layer_cache in kv_cache
    )


def measure(callable, trials=30, warmup=True):
    callable()  # Warmup.
    import cProfile

    if warmup:
        with cProfile.Profile() as pr:
            callable()
        from pstats import Stats

        stats = Stats(pr).sort_stats("cumulative")
    else:
        stats = None
    elapsed_times = []
    for x in range(trials):
        torch.cuda.empty_cache()
        gc.collect()
        [torch.cuda.synchronize(device=i) for i in range(torch.cuda.device_count())]
        start = time.time()
        callable()
        elapsed_times.append(time.time() - start)
        time.sleep(1)
    return np.array(elapsed_times), stats


@inject
def impl_baseline(
    model,
    preamble: torch.Tensor,
    contexts: List[torch.Tensor],
    query: torch.Tensor,
    task: torch.Tensor,
    generation_config,
):
    """
    Cache.None
    Parallel.None
    """
    naive_input = torch.cat([preamble] + contexts + [query, task], dim=-1)
    return model.generate(
        naive_input, use_cache=True, generation_config=generation_config
    )


@inject
def impl_serial(
    model,
    preamble: torch.Tensor,
    contexts: List[torch.Tensor],
    query: torch.Tensor,
):
    """
    Cache.None
    Parallel.Serial
    """
    preamble_cache = model(preamble, use_cache=True).past_key_values
    for context in contexts:
        branch_input = torch.cat([context, query], dim=-1)
        branch_cache = model(
            branch_input, past_key_values=preamble_cache, use_cache=True
        ).past_key_values
    return branch_cache
    # return _concatenate_kv_caches(type(model), [preamble_cache, branch_cache])


def _impl_batched(
    model,
    preamble: torch.Tensor,
    contexts: List[torch.Tensor],
    query: torch.Tensor,
):
    """
    Cache.None
    Parallel.Batch
    """
    preamble_cache = model(preamble, use_cache=True).past_key_values
    branch_input = torch.cat([contexts[0], query], dim=-1)
    return model(
        branch_input, past_key_values=preamble_cache, use_cache=True
    ).past_key_values
    # return _concatenate_kv_caches(type(model), [preamble_cache, branch_cache])


@inject
def impl_batched(
    model,
    preamble: torch.Tensor,
    contexts: List[torch.Tensor],
    query: torch.Tensor,
    topk: int,
):
    """
    Cache.Disk
    Parallel.Batch
    """
    preamble_cache = model(preamble, use_cache=True).past_key_values
    preamble_cache_batched = _broadcast_cache_batch(
        type(model), preamble_cache, len(contexts)
    )
    branches_batched = torch.cat(
        [torch.cat([context, query], dim=-1) for context in contexts], dim=0
    )

    branch_caches_batched = model(
        branches_batched, past_key_values=preamble_cache_batched, use_cache=True
    ).past_key_values
    idx_caches = _select_from_batch(
        type(model),
        branch_caches_batched,
        batch_size=len(contexts),
        idxs=list(range(topk)),
    )
    if topk == 1:
        return idx_caches
    else:
        return _concatenate_kv_caches(type(model), idx_caches, dim="sequence")
    # return _concatenate_kv_caches(type(model), [preamble_cache, selected_branch_cache], dim="sequence")


@inject
def impl_roofline(
    model,
    preamble: torch.Tensor,
    contexts: List[torch.Tensor],
    query: torch.Tensor,
):
    """
    Cache.None
    Parallel.Roofline
    """
    preamble_cache = model(preamble, use_cache=True).past_key_values
    branch_input = torch.cat([contexts[0], query], dim=-1)
    branch_cache = model(
        branch_input, past_key_values=preamble_cache, use_cache=True
    ).past_key_values
    return _concatenate_kv_caches(type(model), [preamble_cache, branch_cache])


@inject
def impl_multiproc(
    model_array,
    dist_preamble: List[torch.Tensor],
    dist_contexts: List[List[torch.Tensor]],
    dist_query: List[torch.Tensor],
):
    """
    Cache.None
    Parallel.Roofline
    """
    n_devices = len(model_array)
    # device_idxs = list(range(len(model_array)))

    threads = []
    results: List[Cache] = [None] * n_devices

    for i in range(n_devices):

        def _returning_thread(**kwargs):
            i = kwargs.pop("i")
            result = _impl_batched(**kwargs)
            results[i] = result

        thread = threading.Thread(
            target=_returning_thread,
            kwargs=dict(
                i=i,
                model=model_array[i],
                preamble=dist_preamble[i],
                contexts=dist_contexts[i],
                query=dist_query[i],
            ),
        )
        thread.start()
        threads.append(thread)

    [thread.join() for thread in threads]
    if any(r is None for r in results):
        raise RuntimeError(f"Found None in results: {results}")
    return results[0]


@inject
def impl_diskcached_serial(
    model,
    preamble_cache: Cache,
    context_paths: List[pathlib.Path],
    query: torch.Tensor,
):
    """
    Cache.Disk
    Parallel.Serial
    """
    for context_path in context_paths:
        context_cache = torch.load(context_path)
        # preamble_and_context_cache = _concatenate_kv_caches(type(model), [preamble_cache, context_cache])
        # branch_input = torch.cat([query], dim=-1)
        query_cache = model(
            query, past_key_values=context_cache, use_cache=True
        ).past_key_values
    return query_cache
    # return _concatenate_kv_caches(type(model), [preamble_and_context_cache, query_cache])


def _impl_cached_batched(
    model,
    context_caches,
    query,
    topk,
):
    contexts_cache_batched = _concatenate_kv_caches(
        type(model), context_caches, dim="batch"
    )
    # preamble_cache_batched = _broadcast_cache_batch(preamble_cache, 20)

    # preamble_and_contexts_cache_batched = _concatenate_kv_caches(type(model), [preamble_cache_batched, contexts_cache_batched], dim="sequence")
    queries_batched = query.repeat(len(context_caches), 1)
    queries_cache_batched = model(
        queries_batched, past_key_values=contexts_cache_batched, use_cache=True
    ).past_key_values

    # res = _select_from_batch(type(model), queries_cache_batched, batch_size=len(context_caches), topk=topk)
    # if topk == 1:
    #     return res
    # else:
    #     cache_list =
    idx_caches = _select_from_batch(
        type(model),
        queries_cache_batched,
        batch_size=len(context_caches),
        idxs=list(range(topk)),
    )
    if topk == 1:
        return idx_caches[0]
    else:
        idx_caches = [idx_caches[0]] + [
            _slice_cache_sequence(
                type(model), idx_cache, slice(N_TOKENS_PREAMBLE, None, None)
            )
            for idx_cache in idx_caches[1:]
        ]
        return _concatenate_kv_caches(type(model), idx_caches, dim="sequence")
    # selected_preamble_and_context_cache = _select_from_batch(queries_cache_batched)
    # return _concatenate_kv_caches(type(model), [selected_preamble_and_context_cache, selected_query_cache])


@inject
def impl_diskcached_batched(
    model,
    preamble_cache: Cache,
    context_paths: List[pathlib.Path],
    query: torch.Tensor,
):
    """
    Cache.Disk
    Parallel.Batch
    """
    context_caches = []
    for context_path in context_paths:
        context_caches.append(torch.load(context_path))
    return _impl_cached_batched(model, context_caches, query)


def _impl_cached_multiproc(
    model_array,
    dist_context_caches: List[Cache],
    query: torch.Tensor,
    topk: int,
):
    """
    Cache.None
    Parallel.Roofline
    """
    n_devices = torch.cuda.device_count()
    dist_query = _dist_tensor(query, n_devices)

    threads = []
    results: List[Cache] = [None] * len(dist_context_caches)

    for i in range(len(dist_context_caches)):

        def _returning_thread(**kwargs):
            i = kwargs.pop("i")
            results[i] = _impl_cached_batched(**kwargs, topk=1)
            # results[i] = result

        thread = threading.Thread(
            target=_returning_thread,
            kwargs=dict(
                i=i,
                model=model_array[i],
                context_caches=dist_context_caches[i],
                query=dist_query[i],
            ),
        )
        thread.start()
        threads.append(thread)

    [thread.join() for thread in threads]
    if any(r is None for r in results):
        raise RuntimeError(f"Found None in results: {results}")
    if topk == 1:
        return results[0]
    else:
        idx_caches = results[:topk]
        if len(idx_caches) < topk:
            idx_caches += results[: (topk - len(idx_caches))]
        idx_caches = [idx_caches[0]] + [
            _slice_cache_sequence(
                type(model_array[0]), idx_cache, slice(N_TOKENS_PREAMBLE, None, None)
            )
            for idx_cache in idx_caches[1:]
        ]
        return _concatenate_kv_caches(
            type(model_array[0]),
            [
                apply_to_cache(idx_cache, lambda x: x.to("cuda:0"))
                for idx_cache in idx_caches
            ],
            dim="sequence",
        )


@inject
def impl_diskcached_multiproc(
    model_array,
    preamble_cache: Cache,
    context_paths: List[pathlib.Path],
    query: torch.Tensor,
):
    context_caches = []
    for context_path in context_paths:
        context_caches.append(torch.load(context_path))
    return _impl_cached_multiproc(model_array, context_caches, query)


@inject
def impl_ramcached_serial(
    model,
    preamble_cache: Cache,
    context_caches: List[Cache],
    query: torch.Tensor,
):
    """
    Cache.Disk
    Parallel.Serial
    """
    for context_cache in context_caches:
        query_cache = model(
            query, past_key_values=context_cache, use_cache=True
        ).past_key_values
    return query_cache


@inject
def impl_ramcached_batched(
    model,
    context_caches: List[Cache],
    query: torch.Tensor,
    topk: int,
):
    return _impl_cached_batched(model, context_caches, query, topk)


@inject
def impl_ramcached_multiproc(
    model_array,
    dist_context_caches: List[Cache],
    query: torch.Tensor,
    topk: int,
):
    return _impl_cached_multiproc(model_array, dist_context_caches, query, topk)


from lorem.text import TextLorem

lorem_text = lambda: TextLorem(srange=(100, 101)).paragraph()
lorem_text_tokenized = lambda: lorem_text().split()
raw_documents = [lorem_text()[: N_TOKENS_CTX * 3] for _ in range(N_CTXS)]
raw_query = lorem_text()[: N_TOKENS_QUERY * 3]
tokenized_documents = [
    lorem_text_tokenized()[: int(N_TOKENS_CTX // 1.2)] for _ in range(N_CTXS)
]
tokenized_query = lorem_text_tokenized()[: int(N_TOKENS_QUERY // 1.2)]


contriver_model = AutoModel.from_pretrained("facebook/contriever").cuda()


@inject
def impl_contriever(
    model,
    preamble,
    contexts,
    context_caches,
    query,
    topk,
):
    def get_embeddings(inputs):
        outputs = contriver_model(inputs)

        # Mean pooling
        def mean_pooling(token_embeddings):
            return token_embeddings.sum(dim=1)

        return mean_pooling(outputs[0])

    context_embeddings = get_embeddings(torch.cat(contexts, dim=0))
    query_embeddings = get_embeddings(query).squeeze()
    branch_weights = (context_embeddings * query_embeddings).sum(1)
    prev_input = torch.cat([preamble] + contexts[:topk] + [query], dim=-1)
    return model(prev_input, use_cache=True).past_key_values


@inject
def impl_contriever_generous(
    model,
    contexts,
    context_caches,
    query,
):
    def get_embeddings(inputs):
        outputs = contriver_model(inputs)

        # Mean pooling
        def mean_pooling(token_embeddings):
            return token_embeddings.sum(dim=1)

        return mean_pooling(outputs[0])

    context_embeddings = get_embeddings(torch.cat(contexts, dim=0))
    query_embeddings = get_embeddings(query).squeeze()
    branch_weights = (context_embeddings * query_embeddings).sum(1)
    return model(
        query, past_key_values=context_caches[0], use_cache=True
    ).past_key_values


@inject
def impl_bm25(
    model,
    preamble,
    contexts,
    query,
    topk,
):
    # Create a BM25 model
    # prev_input = torch.cat([preamble, contexts[0], query], dim=-1)
    bm25 = BM25Okapi(tokenized_documents)
    # Get BM25 scores for each document
    bm25_scores = torch.tensor(list(bm25.get_scores(tokenized_query)))
    prev_input = torch.cat([preamble] + contexts[:topk] + [query], dim=-1)
    return model(prev_input, use_cache=True).past_key_values


@inject
def impl_classic_rag_roofline(
    model,
    context_caches,
    query,
):
    return model(
        query, past_key_values=context_caches[0], use_cache=True
    ).past_key_values


@inject
def impl_bm25_generous(
    model,
    context_caches,
    query,
):
    # Create a BM25 model
    # prev_input = torch.cat([preamble, contexts[0], query], dim=-1)
    bm25 = BM25Okapi(tokenized_documents)
    # Get BM25 scores for each document
    bm25_scores = torch.tensor(list(bm25.get_scores(tokenized_query)))
    return model(
        query, past_key_values=context_caches[0], use_cache=True
    ).past_key_values


@inject
def impl_tf_idf(
    model,
    preamble,
    contexts,
    query,
    topk,
):
    # prev_input = torch.cat([preamble, contexts[0], query], dim=-1)
    vectorizer = TfidfVectorizer()
    tfidf_matrix = vectorizer.fit_transform(raw_documents)

    # Transform the query into TF-IDF representation
    query_tfidf = vectorizer.transform([raw_query])

    # Calculate cosine similarity between the query and documents
    cosine_similarities = cosine_similarity(query_tfidf, tfidf_matrix).flatten()
    tf_idf_branch_weights = torch.tensor(cosine_similarities)
    prev_input = torch.cat([preamble] + contexts[:topk] + [query], dim=-1)
    return model(prev_input, use_cache=True).past_key_values


@inject
def impl_tf_idf_generous(
    model,
    context_caches,
    query,
):
    # prev_input = torch.cat([preamble, contexts[0], query], dim=-1)
    vectorizer = TfidfVectorizer()
    tfidf_matrix = vectorizer.fit_transform(raw_documents)

    # Transform the query into TF-IDF representation
    query_tfidf = vectorizer.transform([raw_query])

    # Calculate cosine similarity between the query and documents
    cosine_similarities = cosine_similarity(query_tfidf, tfidf_matrix).flatten()
    tf_idf_branch_weights = torch.tensor(cosine_similarities)
    return model(
        query, past_key_values=context_caches[0], use_cache=True
    ).past_key_values


@inject
def impl_attention_sort(
    model,
    preamble,
    contexts,
    query,
    topk,
):
    assert topk == 20
    result = None
    preamble_cache = model(preamble, use_cache=True).past_key_values
    for i in range(3):
        input_ids = torch.cat(contexts + [query], dim=-1)
        result = model(
            input_ids, use_cache=True, past_key_values=preamble_cache
        ).past_key_values
    return result


IMPLS_TO_TOPK = {
    "Naive LLM-RAG": [20],
    "Prompt Cache": [20],
    "Attention Sort": [20],
    "BM-25": [8, 4, 2, 1],
    "TF-IDF": [8, 4, 2, 1],
    "Contriever": [8, 4, 2, 1],
    "Superposition (Ours)": [8, 4, 2, 1],
}


@inject
def impl_prompt_cache(
    model,
    preamble_cache,
    modular_context_caches,
    query,
    topk,
):
    assert topk == 20
    prefix_cache = _concatenate_kv_caches(
        type(model), [preamble_cache] + modular_context_caches, dim="sequence"
    )
    return model(query, past_key_values=prefix_cache, use_cache=True).past_key_values


def measure_checkpoint(checkpoint_path):
    print(f"Measuring {checkpoint_path}")
    # checkpoint_pathsafe = checkpoint_path.replace("/", "__")

    # output_dir = ARTIFACT_DIR / checkpoint_pathsafe
    # output_dir.mkdir(exist_ok=True, parents=True)

    torch.autograd.set_grad_enabled(False)
    dtype = torch.bfloat16

    extra_config_kwargs = {}
    if "mpt" in checkpoint_path:
        extra_config_kwargs["max_seq_len"] = 8000

    config = AutoConfig.from_pretrained(checkpoint_path, **extra_config_kwargs)
    tokenizer = AutoTokenizer.from_pretrained(checkpoint_path)
    model = (
        AutoModelForCausalLM.from_pretrained(
            checkpoint_path,
            config=config,
        )
        .to(dtype)
        .eval()
        .cuda()
    )

    inputs = {
        "preamble": torch.randint(1, 10, [1, N_TOKENS_PREAMBLE]).cuda(),
        "contexts": [
            torch.randint(1, 10, [1, N_TOKENS_CTX]).cuda() for _ in range(N_CTXS)
        ],
        "query": torch.randint(1, 10, [1, N_TOKENS_QUERY]).cuda(),
        "task": torch.randint(1, 10, [1, N_TOKENS_TASK]).cuda(),
    }
    for k, v in inputs.items():
        di[k] = v

    import tempfile

    temp_dir = pathlib.Path(tempfile.mkdtemp())
    context_paths = []
    context_caches = []
    modular_context_caches = []
    preamble_cache = model(inputs["preamble"], use_cache=True).past_key_values
    for i, context in enumerate(inputs["contexts"]):
        context_path = temp_dir / f"context_{i:02d}"
        context_paths.append(context_path)
        context_cache = model(
            context, past_key_values=preamble_cache, use_cache=True
        ).past_key_values
        modular_context_cache = model(context, use_cache=True).past_key_values
        context_caches.append(context_cache)
        modular_context_caches.append(modular_context_cache)
        torch.save(context_cache, context_path)

    model_cpu = copy.deepcopy(model).cpu()
    generation_config = GenerationConfig(
        min_new_tokens=N_TOKENS_GEN,
        max_new_tokens=N_TOKENS_GEN,
        # temperature=0.0,
        # do_sample=True,
        output_scores=True,
        return_dict_in_generate=True,
        eos_token_id=None,
        pad_token_id=tokenizer.eos_token_id,
        # pad_token_id=tokenizer.eos_token_id,
    )

    di["model"] = model
    device_count = torch.cuda.device_count()
    # assert 20 % device_count == 0
    di["model_array"] = [model] + [
        copy.deepcopy(model_cpu).to(f"cuda:{i}") for i in range(1, device_count)
    ]
    print(f"Created {device_count} models")
    di["preamble_cache"] = preamble_cache
    di["context_paths"] = context_paths
    di["context_caches"] = context_caches
    di["modular_context_caches"] = modular_context_caches
    di["generation_config"] = generation_config

    di["dist_preamble"] = _dist_tensor(inputs["preamble"], device_count)
    di["dist_contexts"] = _dist_tensor_list(inputs["contexts"], device_count)
    di["dist_query"] = _dist_tensor(inputs["query"], device_count)
    di["dist_task"] = _dist_tensor(inputs["task"], device_count)

    # dist_preamble = _dist_cache(preamble_cache, n_devices)
    # device_idxs = list(range(len(model_array)))

    di["dist_context_caches"] = _dist_cache_list(context_caches, device_count)

    # di["dist_preamble_cache"] = _dist_tensor(inputs["preamble"], device_count)
    # di["dist_contexts"] = _dist_tensor_list(inputs["contexts"], device_count)

    # model_dp = torch.nn.DataParallel(model, device_ids=list(range(torch.cuda.device_count())))
    # from itertools import combinations
    # Segment size values.
    # model_no_kwargs = ModelCachableNoKwargs(model)

    time, _ = measure(impl_baseline)
    baseline_time = np.median(time.flatten())
    print(f"Baseline time = {baseline_time}\tdev = {time.std()}")
    print(f"Baseline time = {baseline_time}\tdev = {time.std()}")

    results = defaultdict(dict)
    results["Naive LLM-RAG"][20] = baseline_time

    for impl_name, impl_fn in [
        # baselines
        # ("Prompt Cache", impl_prompt_cache),
        # ("BM-25", impl_bm25),
        # ("TF-IDF", impl_tf_idf),
        # ("Contriever", impl_contriever),
        # ("Attention Sort", impl_attention_sort),
        # baselines (generous)
        # ("Classic Rag (Roofline)", impl_classic_rag_roofline),
        # ("BM-25", impl_bm25_generous),
        # ("TF-IDF", impl_tf_idf_generous),
        # ("Contriever", impl_contriever_generous),
        # non cached
        # ("impl_serial", impl_serial),
        # ("impl_batched", impl_batched),
        # ("impl_multiproc", impl_multiproc),
        # disk cached
        # ("impl_diskcached_serial", impl_diskcached_serial),
        # ("impl_diskcached_batched", impl_diskcached_batched),
        # ("impl_diskcached_multiproc", impl_diskcached_multiproc),
        # ram cached
        # ("impl_ramcached_serial", impl_ramcached_serial),
        # ("impl_ramcached_batched", impl_ramcached_batched),
        ("impl_ramcached_multiproc", impl_ramcached_multiproc),
    ]:
        # for topk in [8, 4, 2, 1]:
        topks = (
            IMPLS_TO_TOPK[impl_name]
            if impl_name not in ["impl_ramcached_batched", "impl_ramcached_multiproc"]
            else IMPLS_TO_TOPK["Superposition (Ours)"]
        )
        for topk in topks:
            if impl_name in {"Attention Sort", "Prompt Cache"} and topk != 20:
                continue
            elif (
                impl_name
                in {
                    "impl_ramcached_batched",
                    "BM-25",
                    "TF-IDF",
                    "Contriever",
                    "Superposition (Ours)",
                }
                and topk == 20
            ):
                continue
            elif impl_name in {"impl_ramcached_multiproc"} and topk >= 8:
                continue
            print(f"{impl_name} (top-{topk})")
            # continuation_input = torch.cat([inputs["preamble"]] + inputs["contexts"][:1] + [inputs["query"], inputs["task"]], dim=-1)

            def _impl_with_generate():
                path_cache = impl_fn(topk=topk)
                n_tok = cache_len(type(model), path_cache)
                try:
                    if impl_name in {"Naive LLM-RAG", "Attention Sort", "Prompt Cache"}:
                        expected_tokens = 2790
                    elif impl_name in {"BM-25", "TF-IDF", "Contriever"}:
                        expected_tokens = (
                            N_TOKENS_PREAMBLE + topk * N_TOKENS_CTX + N_TOKENS_QUERY
                        )
                    elif impl_name in {
                        "impl_ramcached_batched",
                        "impl_ramcached_multiproc",
                    }:
                        expected_tokens = N_TOKENS_PREAMBLE + topk * (
                            N_TOKENS_CTX + N_TOKENS_QUERY
                        )
                    else:
                        assert False
                    assert n_tok == expected_tokens, f"{path_cache[0][0].shape}"
                    continuation_input = torch.cat(
                        [
                            torch.randint(
                                low=5,
                                high=200,
                                size=[1, n_tok],
                                dtype=torch.long,
                                device=path_cache[0][0].device,
                            ),
                            inputs["task"],
                        ],
                        dim=-1,
                    )
                    res = model.generate(
                        continuation_input,
                        attention_mask=torch.ones_like(continuation_input),
                        past_key_values=path_cache,
                        generation_config=generation_config,
                    )
                    assert (
                        res.sequences[0].numel()
                        == expected_tokens + N_TOKENS_TASK + N_TOKENS_GEN
                    )
                except Exception as e:
                    import traceback

                    traceback.print_exc()
                    breakpoint()
                    pass
                return None

            time, _ = measure(_impl_with_generate)
            avg_time = np.median(time.flatten())

            results[impl_name][topk] = avg_time
            print(f"\tavg_time = {avg_time}")
            print(f"\tdev_time = {time.std()}")
            print(f"\tavg_speedup = {baseline_time / avg_time}")

    del model
    del inputs
    torch.cuda.empty_cache()
    return dict(results)


def main_baselines():
    # impls = ["Naive LLM-RAG", "BM-25", "TF-IDF", "Contriever", "Attention Sort", "Prompt Cache", "Superposition (Ours)"]

    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("model")

    checkpoint_path = parser.parse_args().model
    checkpoint_pathsafe = checkpoint_path.split("/")[1]

    results = measure_checkpoint(checkpoint_path)
    baseline_time = results["Naive LLM-RAG"][20]
    with open(
        f"/mnt/task_wrapper/user_output/artifacts/{checkpoint_pathsafe}.csv", "w"
    ) as fp:
        for impl, topks in IMPLS_TO_TOPK.items():
            for topk in topks:
                if impl == "Superposition (Ours)":
                    candidate_impls = [
                        "impl_ramcached_multiproc",
                        "impl_ramcached_batched",
                    ]
                    time = min(
                        results[candidate_impl][topk]
                        for candidate_impl in candidate_impls
                        if topk in results[candidate_impl]
                    )
                else:
                    if topk not in results[impl]:
                        print(results)
                        print(impl)
                    time = results[impl][topk]
                speedup = baseline_time / time
                print([time, speedup])
                fp.write(f"{checkpoint_pathsafe},{impl},{topk},{time},{speedup}\n")
        # print(df)
        # df.to_csv(f'/mnt/task_wrapper/user_output/artifacts/{checkpoint_pathsafe}.csv')


main_baselines()
